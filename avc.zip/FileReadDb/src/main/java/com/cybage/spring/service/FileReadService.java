package com.cybage.spring.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.cybage.spring.model.User;

public interface FileReadService {

	List<User> findAll();

	boolean savaDataFromUploadfile(MultipartFile file); 

}
