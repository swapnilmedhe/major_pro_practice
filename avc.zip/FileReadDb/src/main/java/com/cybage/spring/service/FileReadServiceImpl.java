package com.cybage.spring.service;

import java.util.Iterator;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.commons.io.FilenameUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.cybage.spring.model.User;
import com.cybage.spring.repository.FileReadRepository;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

@Service
@Transactional
public class FileReadServiceImpl implements FileReadService {

	@Autowired 
	private FileReadRepository fileReadRepository;

	@Override
	public List<User> findAll() {
		// TODO Auto-generated method stub
		return (List<User>) fileReadRepository.findAll();
	}

	@Override
	public boolean savaDataFromUploadfile(MultipartFile file) {
		
		boolean isFlag =false;
		String extension = FilenameUtils.getExtension(file.getOriginalFilename());
		if(extension.equalsIgnoreCase("xls") || extension.equalsIgnoreCase("xlsx") ){
			isFlag = readDataFromExcel(file);
		}

		return isFlag;
	}

	private boolean readDataFromExcel(MultipartFile file) {
		Workbook workbook = getWorkBook(file);
		Sheet sheet = workbook.getSheetAt(0);
		
		Iterator<Row> rows = sheet.iterator();
		rows.next();
		while(rows.hasNext()){
			Row row = rows.next();
			User user = new User();
			if(row.getCell(0).getCellType() == Cell.CELL_TYPE_STRING){
				user.setFirstname(row.getCell(0).getStringCellValue());
			}
			if(row.getCell(1).getCellType() == Cell.CELL_TYPE_STRING){
				user.setLastname(row.getCell(1).getStringCellValue());
			}
			if(row.getCell(2).getCellType() == Cell.CELL_TYPE_STRING){
				user.setEmail(row.getCell(2).getStringCellValue());
			}
			if(row.getCell(3).getCellType() == Cell.CELL_TYPE_NUMERIC){
				
				String phoneNumber = NumberToTextConverter.toText(row.getCell(3).getNumericCellValue());
				user.setPhoneNumber(phoneNumber);
			}else if(row.getCell(3).getCellType() == Cell.CELL_TYPE_STRING){
				user.setPhoneNumber(row.getCell(3).getStringCellValue());
			} 
			
			user.setFileType(FilenameUtils.getExtension(file.getOriginalFilename()));
			fileReadRepository.save(user);
		}
		
		return true;
	}

	private Workbook getWorkBook(MultipartFile file) {
		Workbook workbook =null;
		String extension = FilenameUtils.getExtension(file.getOriginalFilename());
		
		try {
			
			if(extension.equalsIgnoreCase("xls")){
				workbook = new XSSFWorkbook(file.getInputStream());
			}else if(extension.equalsIgnoreCase("xlsx")) {
				workbook = new XSSFWorkbook(file.getInputStream());
			}
			return workbook;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
}
