package com.cybage.spring.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.commons.io.FilenameUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.cybage.spring.model.User;
import com.cybage.spring.repository.FileReadRepository;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;


@Service
@Transactional
public class FileReadServiceImpl implements FileReadService {

	@Autowired 
	private FileReadRepository fileReadRepository;

	@Override
	public List<User> findAll() {
		// TODO Auto-generated method stub
		return (List<User>) fileReadRepository.findAll();
	}

	@Override
	public boolean savaDataFromUploadfile(MultipartFile file) {
		
		boolean isFlag =false;
		String extension = FilenameUtils.getExtension(file.getOriginalFilename());
		if(extension.equalsIgnoreCase("xls") || extension.equalsIgnoreCase("xlsx") ){
			isFlag = readDataFromExcel(file);
		}

		return isFlag;
	}

	private boolean readDataFromExcel(MultipartFile file) {
		Workbook workbook = getWorkBook(file);
		Sheet sheet = workbook.getSheetAt(0);
		Iterator<Row> rows = sheet.iterator();
		String question=null,opt1=null,opt2=null, opt3=null, opt4=null,correctans=null,dlevel=null,sub_topic=null, marks=null;
		long id = 0;
		rows.next();
		int counter =0;
		String [] options = new String[4];
		while(rows.hasNext()){
			Row row = rows.next();
			User user = new User();
			
			System.out.println("id-------: "+new DataFormatter().formatCellValue(row.getCell(0)));
			System.out.println("marks-------: "+new DataFormatter().formatCellValue(row.getCell(4)));
			if(counter ==0){
					id=Long.parseLong(new DataFormatter().formatCellValue(row.getCell(0)));
					//System.out.println("ID------->"+id+"VALUE___>"+Long.parseLong(row.getCell(0).getStringCellValue()));
				
			}
			if(row.getCell(1).getCellType() == Cell.CELL_TYPE_STRING){
				if(counter ==0)
					//user.setQuestion(row.getCell(1).getStringCellValue());
					question=row.getCell(1).getStringCellValue();
				
			}
			if(row.getCell(2).getCellType() == Cell.CELL_TYPE_STRING){
				// internal checking
				options[counter]=row.getCell(2).getStringCellValue();
			}
			//	System.out.println("------------------------------->"+row.cell.getStringCellValue());
							
			if(row.getCell(3).getCellType() == Cell.CELL_TYPE_STRING){
				if(counter ==0)
				//user.setCorr_ans(row.getCell(3).getStringCellValue());
					correctans=row.getCell(3).getStringCellValue();
			}
			
				if(counter ==0){
				//user.setMarks(row.getCell(4).getStringCellValue());	
					marks=new DataFormatter().formatCellValue(row.getCell(4));
			}
			if(row.getCell(5).getCellType() == Cell.CELL_TYPE_STRING){
				if(counter ==0)
				//user.setDlevel(row.getCell(5).getStringCellValue());	
					dlevel =row.getCell(5).getStringCellValue();
			}
			if(row.getCell(6).getCellType() == Cell.CELL_TYPE_STRING){
				if(counter ==0)
				//user.setSub_topic(row.getCell(6).getStringCellValue());	
					sub_topic =row.getCell(6).getStringCellValue();
			}
		
			
			user.setFileType(FilenameUtils.getExtension(file.getOriginalFilename()));
			
		
			
			System.out.println("---- set in parameter const-------------------->");
				
			
		
			for(int i=0; i<options.length; i++){
				System.out.println(options[i]);
			}
			
			if(counter==3){
				opt1=options[0];
				opt2=options[1];
				opt3=options[2];
				opt4=options[3];
				User user1 = new User(
						id,question,opt1,opt2, opt3, opt4,correctans,dlevel,sub_topic,marks,user.getFileType());
				//fileReadRepository.save(
				System.out.println("---- set in parameter const-------------------->");
				System.out.println(user1);
				fileReadRepository.save(user1);
				//options =null;
				counter =0;
			}
			else{
				counter++;
			}
			
			/*user.setFileType(FilenameUtils.getExtension(file.getOriginalFilename()));
			fileReadRepository.save(user);*/
		}
		return true;
	}

	private Workbook getWorkBook(MultipartFile file) {
		Workbook workbook =null;
		String extension = FilenameUtils.getExtension(file.getOriginalFilename());
		
		try {
			
			if(extension.equalsIgnoreCase("xls")){
				workbook = new XSSFWorkbook(file.getInputStream());
			}else if(extension.equalsIgnoreCase("xlsx")) {
				workbook = new XSSFWorkbook(file.getInputStream());
			}
			return workbook;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
}
