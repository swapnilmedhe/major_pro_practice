package com.cybage.spring.repository;

import org.springframework.data.repository.CrudRepository;

import com.cybage.spring.model.User;

public interface FileReadRepository extends CrudRepository<User, Long> {

}
