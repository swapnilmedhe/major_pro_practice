

package com.cybage.spring.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.web.multipart.MultipartFile;

@Entity
@Table(name="test")
public class Exam {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private long id;
	
	@Column(name="questions")
	private String questions;
	
	@Column(name="options")
	private String options;
	
	@Column(name="correctanswer")
	private String emacorrectansweril;
	
	@Column(name="marks")
	private String marks;
	
	@Column(name="difficultylevel")
	private String difficultylevel;
	
	@Column(name="subtopics")
	private String subtopics;
	@Transient
	private MultipartFile file ;

	public Exam() {
		// TODO Auto-generated constructor stub
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getQuestions() {
		return questions;
	}

	public void setQuestions(String questions) {
		this.questions = questions;
	}

	public String getOptions() {
		return options;
	}

	public void setOptions(String options) {
		this.options = options;
	}

	public String getEmacorrectansweril() {
		return emacorrectansweril;
	}

	public void setEmacorrectansweril(String emacorrectansweril) {
		this.emacorrectansweril = emacorrectansweril;
	}

	public String getMarks() {
		return marks;
	}

	public void setMarks(String marks) {
		this.marks = marks;
	}

	public String getDifficultylevel() {
		return difficultylevel;
	}

	public void setDifficultylevel(String difficultylevel) {
		this.difficultylevel = difficultylevel;
	}

	public String getSubtopics() {
		return subtopics;
	}

	public void setSubtopics(String subtopics) {
		this.subtopics = subtopics;
	}

	public MultipartFile getFile() {
		return file;
	}

	public void setFile(MultipartFile file) {
		this.file = file;
	}

	public Exam(long id, String questions, String options, String emacorrectansweril, String marks,
			String difficultylevel, String subtopics, MultipartFile file) {
		super();
		this.id = id;
		this.questions = questions;
		this.options = options;
		this.emacorrectansweril = emacorrectansweril;
		this.marks = marks;
		this.difficultylevel = difficultylevel;
		this.subtopics = subtopics;
		this.file = file;
	}

	@Override
	public String toString() {
		return "Exam [id=" + id + ", questions=" + questions + ", options=" + options + ", emacorrectansweril="
				+ emacorrectansweril + ", marks=" + marks + ", difficultylevel=" + difficultylevel + ", subtopics="
				+ subtopics + ", file=" + file + "]";
	}
	
	
	/*public User(long id, String firstname, String lastname, String email, String phoneNumber, String fileType) {
		super();
		this.id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.fileType = fileType;
	}
	
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getFileType() {
		return fileType;
	}
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public MultipartFile getFile() {
		return file;
	}

	public void setFile(MultipartFile file) {
		this.file = file;
	}
	*/
}
