package com.cybage.spring.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.web.multipart.MultipartFile;

@Entity
@Table(name="user")
public class User {

	@Id
	@Column(name="id")
	private long id;
	
	private String question,opt1,opt2,opt3,opt4,corr_ans,dlevel,sub_topic,marks;
	
	
	@Column(name="file_type")
	private String fileType;
	
	@Transient
	private MultipartFile file ;

	public User() {
		
	}
	
	
	public User(long id, String question, String opt1, String opt2, String opt3, String opt4, String corr_ans,
			String dlevel, String sub_topic, String marks, String fileType) {
		super();
		this.id = id;
		this.question = question;
		this.opt1 = opt1;
		this.opt2 = opt2;
		this.opt3 = opt3;
		this.opt4 = opt4;
		this.corr_ans = corr_ans;
		this.dlevel = dlevel;
		this.sub_topic = sub_topic;
		this.marks = marks;
		this.fileType = fileType;
	}

	

	public String getOpt1() {
		return opt1;
	}


	public void setOpt1(String opt1) {
		this.opt1 = opt1;
	}


	public String getOpt2() {
		return opt2;
	}


	public void setOpt2(String opt2) {
		this.opt2 = opt2;
	}


	public String getOpt3() {
		return opt3;
	}


	public void setOpt3(String opt3) {
		this.opt3 = opt3;
	}


	public String getOpt4() {
		return opt4;
	}


	public void setOpt4(String opt4) {
		this.opt4 = opt4;
	}


	public String getFileType() {
		return fileType;
	}
	
	
	

	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public String getMarks() {
		return marks;
	}

	public void setMarks(String marks) {
		this.marks = marks;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	
	public String getCorr_ans() {
		return corr_ans;
	}

	public void setCorr_ans(String corr_ans) {
		this.corr_ans = corr_ans;
	}

	public String getDlevel() {
		return dlevel;
	}

	public void setDlevel(String dlevel) {
		this.dlevel = dlevel;
	}

	public String getSub_topic() {
		return sub_topic;
	}

	public void setSub_topic(String sub_topic) {
		this.sub_topic = sub_topic;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public MultipartFile getFile() {
		return file;
	}

	public void setFile(MultipartFile file) {
		this.file = file;
	}


	@Override
	public String toString() {
		return "User [id=" + id + ", question=" + question + ", opt1=" + opt1 + ", opt2=" + opt2 + ", opt3=" + opt3
				+ ", opt4=" + opt4 + ", corr_ans=" + corr_ans + ", dlevel=" + dlevel + ", sub_topic=" + sub_topic
				+ ", marks=" + marks + ", fileType=" + fileType + ", file=" + file + "]";
	}
	
	
	
}
